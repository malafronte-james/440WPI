/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package SPI;

public class Ampeater {
	
	public static char rectifierMode;
	public static int numCells;
	public static int cellRef;
	public static char voltageBox;
        private static String[] args;
	
	public static char getRectifierMode(char rectifierMode) {
		return rectifierMode;
	} // end getRectifierMode
	
	// storing the variable input into rectifier mode
	public static void setRectifierMode(){ 
			 rectifierMode = AmpeaterDisplay.getInput().charAt(0);
			 System.out.println("Rectifier Mode is set to: " + AmpeaterDisplay.getInput());
	} // end setRectifierMode

	public static int getNumCells(int numCells){
		return numCells;
	} // end getNumCells
	
	public static void setNumCells(){
		 numCells = Integer.parseInt(AmpeaterDisplay.getInput());
		 System.out.println("Number of cells set is: " + AmpeaterDisplay.getInput());
	} // end setNumCells

	public static int getCellRef(int cellRef){
		return cellRef;
	} // end getCellRef
	
	public static void setCellRef(){
		 cellRef = Integer.parseInt(AmpeaterDisplay.getInput());
		 System.out.println("Cell #1 Ref is set to: " + AmpeaterDisplay.getInput());
	}// end setCellRef
	

	public static char getVoltageBox(char voltageBox) {
		return voltageBox;
	} // end getVoltageBox
	
	public static void setVoltageBox(){
		voltageBox = AmpeaterDisplay.getInput().charAt(0);
		 System.out.println("Overall Voltage Box is set to: " + AmpeaterDisplay.getInput());
	} // end setVoltageBox

	// calls the getters for all of the inputs and stores the values in strings that will be appended to the display
	public static void summaryOfInputs(){
		
		getRectifierMode(rectifierMode);
		String recM = String.valueOf(rectifierMode);
		
		getNumCells(numCells);
		String numC = String.valueOf(numCells);
		
		getCellRef(cellRef);
		String cellR = String.valueOf(cellRef);
		
		getVoltageBox(voltageBox);
		String voltB = String.valueOf(voltageBox);
		
		AmpeaterDisplay.setDisplay("Summary of Inputs: \n");
		AmpeaterDisplay.appendDisplay("\nRectifier Mode: " + recM);
		AmpeaterDisplay.appendDisplay("\nNumber of Cells: " + numC);
		AmpeaterDisplay.appendDisplay("\nCell Ref/Multi: " + cellR);
		AmpeaterDisplay.appendDisplay("\nOverall Voltage Box: " + voltB + "\n");
	} // end summaryOfInputs
	
	public static void run(){
                SPItutorial spi = new SPItutorial();
                spi.testGUI();
                SPItutorial.main(args); // this is how I got it to work with the help of hints seems to be running
                
		
                
                
                
            //loop
		/* * SPI read voltages
		 * Alarm check that voltages are safe
		 * Data storage - print voltages to text file
		 * Printer - print paper
		 * Repeat until finished*
		*/
	}
} // end class


