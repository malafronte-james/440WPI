/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package SPI;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.*;

import javax.swing.*;

public class AmpeaterDisplay extends JFrame {
	
	// input string is used to store the input of the user from the inputField
	private static String input;
	
	// used to check that the input is equal to y or n
	private char characterInput;
	
	// used to determine which output to display, and which input to take
	private int counter;
	
	// sets number of questions 
	private int maxCount = 5;
	
	// GUI properties
	private JPanel northPanel, centerPanel, northDisplayPanel, cetnerDisplayPanel, northInputPanel, centerButtonPanel, buttonPanel;
	private static JTextArea display;
	private JTextField inputField;
	private JButton enterButton, resetButton, nextButton, previousButton,startButton;
	
	
	// creates a new frame 
	public AmpeaterDisplay(){
		JFrame frame = new JFrame();
		frame.setTitle("Ampeater");
		frame.setSize(800, 480);
		
		buildNorthPanel();
		frame.getContentPane().add(northPanel, "North");
		
		buildCenterPanel();
		frame.getContentPane().add(centerPanel, "Center");
		frame.getContentPane().add(buttonPanel, "Center");
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setVisible(true);
		
	}
		
	// Used to create text box to display text
		private void buildNorthPanel()
		  {
		       northPanel = new JPanel(); //create new JPanel and define layout
		       northPanel.setLayout(new BorderLayout());
		      
		       northDisplayPanel = new JPanel();// instantiate variables and set layouts
		       display = new JTextArea(8, 50);
		       northDisplayPanel.add(Box.createRigidArea(new Dimension(0, 100)));
		       northDisplayPanel.add(display);
		       northPanel.add("North", northDisplayPanel);
		       
		       counter = 1;
		       displaySwitch(counter);
		       
		       display.setEditable(false);
		       
		       northInputPanel = new JPanel();
		       inputField = new JTextField(15);
		       inputField.setEditable(true); 
		       northInputPanel.add(inputField);
		       northPanel.add("South", northInputPanel);
		    
		       add("North", northPanel);
		  }//End of NorthPanel
		
		private void buildCenterPanel(){
			centerPanel = new JPanel();
			centerPanel.setLayout(new BorderLayout());
			
			buttonPanel = new JPanel();
	        
                        enterButton = new JButton("Enter");
                        enterButton.setEnabled(true);
                        buttonPanel.add(enterButton);
                        enterButton.addActionListener(
	        		new ActionListener(){
	        			public void actionPerformed(ActionEvent evt){
	        				enterButtonActionPerformed(evt);
	        			}

					}); // end call to Action Listener
	        
                        resetButton = new JButton("Reset");
                        resetButton.setEnabled(true);
                        buttonPanel.add(resetButton);
                        resetButton.addActionListener(
	        		new ActionListener(){
	        			public void actionPerformed(ActionEvent evt){
	        				resetButtonActionPerformed(evt);
	        			}

					}); // end call to Action Listener
                        startButton = new JButton("Start");
                        startButton.setEnabled(true);
                        buttonPanel.add(startButton);
                        startButton.addActionListener(
	        		new ActionListener(){
	        			public void actionPerformed(ActionEvent evt){
	        				startButtonActionPerformed(evt);
	        			}

					}); // end call to Action Listener
                
                                add("Center",  buttonPanel);
		
			nextButton = new JButton("Next");
			nextButton.setEnabled(false);
			buttonPanel.add(nextButton);
			nextButton.addActionListener(
					new ActionListener(){
						public void actionPerformed(ActionEvent evt){
							nextButtonActionPerformed(evt);
        			}

				}); // end call to Action Listener
   
                                add("Center",  buttonPanel);
			
			previousButton = new JButton("Previous");
                        previousButton.setEnabled(false);
                        buttonPanel.add(previousButton);
                        previousButton.addActionListener(
	        		new ActionListener(){
	        			public void actionPerformed(ActionEvent evt){
	        				previousButtonActionPerformed(evt);
	        			}

					}); // end call to Action Listener
	   
		
		} // end buildCenterPanel
		
	// this is a switch that uses the count variable to get the output for the display.
		private void displaySwitch(int outputCount){
			outputCount = counter;
			String outputSwitchString = null;
			if (outputCount <= maxCount && outputCount > 0){
				switch (outputCount) {
					case 1: outputSwitchString = "Enter Rectifier Mode: (y/n)?";
						break; 
					case 2: outputSwitchString = "Enter Number of Cells: ";
						break; 
					case 3: outputSwitchString = "Enter Cell #1 Ref/Multi: ";
						break;
					case 4: outputSwitchString = "Overall Voltage Box: (y/n)";
						break;
					case 5: outputSwitchString = "\nPlease Verify Input Summary: (y/n)";
							Ampeater.summaryOfInputs();
						break;
					} // end switch
					System.out.println("output is: " + outputSwitchString);
					if (counter < 5){
						display.setText(outputSwitchString);
					}else if (counter == 5){
						display.append(outputSwitchString);
					}else{
						display.setText(outputSwitchString);
					} // end if else
					
			}else {
				System.out.println("ERROR: counter is out of bounds. Counter equals: " + counter);
				JOptionPane.showMessageDialog(null, "ERROR: counter is invalid. Counter equals: " + counter);
			} // end if else
		} // end displaySwitch
		
		private void inputSwitch(int inputCount){
			inputCount = counter;
			if (counter <= maxCount || counter > 0){
				switch (inputCount) {
					case 1: Ampeater.setRectifierMode();
						break;
					case 2: Ampeater.setNumCells();
						break;
					case 3: Ampeater.setCellRef();
						break;
					case 4: Ampeater.setVoltageBox();
						break;
					case 5: System.out.println("Input 5");
						break;
					} // end switch
					System.out.println("Input number is: " + inputCount );
			}else {
				System.out.println("ERROR: counter is out of bounds. Counter equals: " + counter);
			} // end if else
		} // end inputSwitch
		
		
		private void enterButtonActionPerformed(ActionEvent evt) {
				
			if (counter == 1){
				characterCheck();
			}else if (counter == 2) {
				integerCheck();
			}else if (counter == 3){
				integerCheck();
			}else if (counter == 4){
				integerCheck();
			}else if (counter == 5){
				verifySummaryOfInputs();
			}else {
				JOptionPane.showMessageDialog(null, "ERROR: counter is invalid. Counter equals: " + counter);
			}
		} // end actionperformed
		
		private void resetButtonActionPerformed(ActionEvent evt) {		
			counter = 1;
			inputField.setText("");
			inputField.setEditable(true);
			nextButton.setEnabled(false);
			previousButton.setEnabled(false);
			displaySwitch(counter);
		} // end actionperformed
		
		private void nextButtonActionPerformed(ActionEvent evt) {
			counter++;
			displaySwitch(counter);
			previousButton.setEnabled(true);
			inputField.setEditable(true);
			nextButton.setEnabled(false);
		} // end actionperformed
		
		private void previousButtonActionPerformed(ActionEvent evt) {		
			counter--;
                        inputField.setEditable(true);
			displaySwitch(counter);
		} // end actionperformed
                
                private void startButtonActionPerformed(ActionEvent evt) {
			display.setText("");
			Ampeater.run();
		} // end actionperformed
                
		

		private void characterCheck(){
			characterInput = inputField.getText().charAt(0);
			if (characterInput == 'y' || characterInput == 'n'){
			setInput(inputField.getText());
			}else {
				JOptionPane.showMessageDialog(null, "ERROR: You must enter a 'y', or an 'n'.");
				System.out.println("ERROR y or n");
			} // end if else
		} // end characterCheck
			
		private void integerCheck(){
			// integer limits error handling go here
			setInput(inputField.getText());
		} // end integerCheck
		
		public void setInput(String inputSet){
			input = inputSet;
			inputSwitch(counter);
			display.append("\n" + inputField.getText());
			inputField.setText("");
			inputField.setEditable(false);
			nextButton.setEnabled(true);
		} // end setInput
		
		public static String getInput(){
			return input;
		} // end getInput
		
		public static void setDisplay(String displaySet){
			display.setText(displaySet);
		} // end setDisplay
		
		public static void appendDisplay(String displayAppend){
			display.append(displayAppend);
		} // end appendDisplay
		
		public void verifySummaryOfInputs(){
			characterInput = inputField.getText().charAt(0);
			if (characterInput == 'y'){
				System.out.println("Summary of inputs: yes. counter incrimented.");
				setInput(inputField.getText());
                               
			}else if (characterInput == 'n'){
				System.out.println("Summary of inputs: no. reset counter.");
				counter = 0;
				setInput(inputField.getText());
			}else {
				JOptionPane.showMessageDialog(null, "ERROR: You must enter a 'y', or an 'n'.");
				System.out.println("ERROR y or n");
			}
		} // end verifySummary of Inputs
		
		public static void main( String args[] )
		   {
			AmpeaterDisplay gui = new AmpeaterDisplay();
                        new Ampeater();
                    
		   } // end method main
		   
} // end class
